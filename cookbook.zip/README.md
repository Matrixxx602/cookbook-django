# Moja Aplikacja Django
Prosta aplikacja webowa zbudowana w Django.

## Jak uruchomić?
1. Sklonuj repozytorium: `git clone https://github.com/Matrixxx602/cookbook-django.git`
2. Zainstaluj zależności: `pip install -r requirements.txt`
3. Uruchom serwer: `python manage.py runserver`