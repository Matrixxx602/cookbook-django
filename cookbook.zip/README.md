# Moja Aplikacja Django
Prosta aplikacja webowa zbudowana w Django.
Aplikacja wrzucona jest na chmurę AWS i dostepna w sieci.

## Jak uruchomić?

## METODA 1

1. Wejdz w poniższy link:
`http://cookbook.eu-central-1.elasticbeanstalk.com`


## METODA 2

1. Sklonuj repozytorium: `git clone https://github.com/Matrixxx602/cookbook-django.git`
2. Zainstaluj zależności: `pip install -r requirements.txt`
3. Uruchom serwer: `python manage.py runserver`